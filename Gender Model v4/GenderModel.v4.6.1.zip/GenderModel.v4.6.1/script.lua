--       ___           ___                         ___           ___                    ___           ___           ___                                              
--      /  /\         /  /\          __           /  /\         /  /\                  /  /\         /  /\         /  /\           ___         ___           ___     
--     /  /::\       /  /:/         |  |\        /  /::\       /  /::\                /  /::\       /  /::\       /  /::\         /__/\       /  /\         /__/\    
--    /__/:/\:\     /  /:/          |  |:|      /  /:/\:\     /__/:/\:\              /__/:/\:\     /  /:/\:\     /  /:/\:\        \__\:\     /  /::\        \  \:\   
--   _\_ \:\ \:\   /  /::\____      |  |:|     /  /::\ \:\   _\_ \:\ \:\            _\_ \:\ \:\   /  /:/  \:\   /  /::\ \:\       /  /::\   /  /:/\:\        \__\:\  
--  /__/\ \:\ \:\ /__/:/\:::::\     |__|:|__  /__/:/\:\ \:\ /__/\ \:\ \:\          /__/\ \:\ \:\ /__/:/ \  \:\ /__/:/\:\_\:\   __/  /:/\/  /  /::\ \:\       /  /::\ 
--  \  \:\ \:\_\/ \__\/~|:|~~~~     /  /::::\ \  \:\ \:\_\/ \  \:\ \:\_\/          \  \:\ \:\_\/ \  \:\  \__\/ \__\/~|::\/:/  /__/\/:/~~  /__/:/\:\_\:\     /  /:/\:\
--   \  \:\_\:\      |  |:|        /  /:/~~~~  \  \:\ \:\    \  \:\_\:\             \  \:\_\:\    \  \:\          |  |:|::/   \  \::/     \__\/  \:\/:/    /  /:/__\/
--    \  \:\/:/      |  |:|       /__/:/        \  \:\_\/     \  \:\/:/              \  \:\/:/     \  \:\         |  |:|\/     \  \:\          \  \::/    /__/:/     
--     \  \::/       |__|:|       \__\/          \  \:\        \  \::/                \  \::/       \  \:\        |__|:|~       \__\/           \__\/     \__\/      
--      \__\/         \__\|                       \__\/         \__\/                  \__\/         \__\/         \__\|                                             

-- PhysBoneAPI by ChloeSpacedOut
-- KattArmour by Katt

--Config--
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(true)
vanilla_model.HELMET:setVisible(true)
vanilla_model.HELMET_ITEM:setVisible(true)
vanilla_model.CHESTPLATE:setVisible(true)
vanilla_model.LEGGINGS:setVisible(true)
vanilla_model.BOOTS:setVisible(true)
vanilla_model.PLAYER:setVisible(false)

--Requires--
local armorHuman = require("KattArmor")()
local physBone = require('physBoneAPI')
models.model:setPrimaryTexture("SKIN")

--Katt Armor--
armorHuman.Armor.Chestplate:addParts(models.model.Body.physBoobas.Chestplate):addTrimParts(models.model.Body.physBoobas.ChestplateTrim)

--PhysBone--
function events.entity_init()
	physBone.physBoobas:setGravity(1)
	physBone.physBoobas:setAirResistance(0)
	physBone.physBoobas:setSpringForce(100)
	physBone.physBoobas:setVecMod(vec(0,1,1))
end

--Make the Player Head not Render in First Person--
function events.render(_,context)
    models.model.Head:setVisible(not (renderer:isFirstPerson() and context == "OTHER"))
end

--Action Wheel--
local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)
		
--Armour Toggles

--Helmet--
function pings.helmet(state)
	vanilla_model.HELMET:setVisible(not state)
  end
  
  local toggleaction = mainPage:newAction()
	:title("Disable Helmet")
	:toggleTitle("Enable Helmet")
	:item("iron_helmet")
	:toggleItem("air")
	:setOnToggle(pings.helmet)

--Chestplate--
  function pings.chestplate(state)
	vanilla_model.CHESTPLATE:setVisible(not state)
	models.model.Body.physBoobas.Chestplate.Chestplate:setVisible(not state)
    models.model.Body.physBoobas.ChestplateTrim.Chestplate:setVisible(not state)
  end

  local toggleaction = mainPage:newAction()
	:title("Disable Chestplate")
	:toggleTitle("Enable Chestplate")
	:item("iron_chestplate")
	:toggleItem("air")
	:setOnToggle(pings.chestplate)

--Leggings--
function pings.leggings(state)
	vanilla_model.LEGGINGS:setVisible(not state)
  end
  
  local toggleaction = mainPage:newAction()
	:title("Disable Leggings")
	:toggleTitle("Enable Leggings")
	:item("iron_leggings")
	:toggleItem("air")
	:setOnToggle(pings.leggings)

--Boots--

function pings.boots(state)
	vanilla_model.BOOTS:setVisible(not state)
  end
  
  local toggleaction = mainPage:newAction()
	:title("Disable Leggings")
	:toggleTitle("Enable Leggings")
	:item("iron_leggings")
	:toggleItem("air")
	:setOnToggle(pings.boots)
