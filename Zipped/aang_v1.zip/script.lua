-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
end

--tick event, called 20 times per second
function events.tick()
  --code goes here
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end

function events.tick()
  local playerPos = player:getPos() -- Get player's position
  
  -- Calculate the horizontal offset based on world time
  local offsetX = math.sin(world.getTime() / 10)
  local offsetZ = math.cos(world.getTime() / 10)
  
  -- Calculate the vertical offset based on a sine wave with an increased amplitude
  local amplitude = 2 -- Set amplitude to desired height
  local offsetY = math.max(0, math.sin(world.getTime() / 20) * amplitude) + 0.35 -- Ensure offsetY doesn't go below zero and add 0.25 to lift particles higher
  
  -- Create a position vector with the calculated offsets
  local cloudPos = vec(playerPos.x + offsetX, playerPos.y + offsetY, playerPos.z + offsetZ)
  
  -- Spawn cloud particles at the calculated position
  particles:newParticle("cloud", cloudPos)
end






