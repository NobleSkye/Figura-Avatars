-- Auto generated script file --

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.PLAYER:setVisible(false)
vanilla_model.CAPE:setVisible(false)
models.model:setPrimaryTexture("SKIN")